%populate {
    object WiFi {
        object AccessPoint {
            object 'vap2g0priv' {
                parameter BridgeInterface = "{{BD.Bridges.Lan.Name}}";
            }
            object 'vap5g0priv' {
                parameter BridgeInterface = "{{BD.Bridges.Lan.Name}}";
            }
            object 'vap2g0guest' {
                parameter BridgeInterface = "{{BD.Bridges.Guest.Name}}";
            }
            object 'vap5g0guest' {
                parameter BridgeInterface = "{{BD.Bridges.Guest.Name}}";
            }
        }
    }
}
