%populate {
    object WiFi {
        object SSID {
            instance add ("ep5g0") {
                parameter LowerLayers = "Device.WiFi.Radio.2.";
            }
        }
        object EndPoint {
            instance add ("ep5g0") {
                parameter SSIDReference = "WiFi.SSID.ep5g0";
                parameter Enable = 0;
                parameter BridgeInterface = "{{BD.Bridges.Lan.Name}}";
                object Security {
                    parameter ModesSupported = "None,WEP-64,WEP-128,WEP-128iv,WPA-Personal,WPA2-Personal,WPA-WPA2-Personal,WPA3-Personal,WPA2-WPA3-Personal";
                }
                object WPS {
                    parameter Enable = 1;
                    parameter ConfigMethodsEnabled = "PhysicalPushButton,VirtualPushButton,VirtualDisplay,PIN";
                }
            }
        }
    }
}
