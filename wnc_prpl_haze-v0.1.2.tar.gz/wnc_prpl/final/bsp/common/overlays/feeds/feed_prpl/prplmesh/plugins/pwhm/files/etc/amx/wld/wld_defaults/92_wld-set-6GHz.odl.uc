%populate {
    object WiFi {
        object Radio {
            instance add ("wifi2") {
                parameter OperatingFrequencyBand = "6GHz";
                parameter Enable = 1;
                parameter AutoChannelEnable = 0;
                parameter Channel = 33;
                parameter IEEE80211hEnabled = true;
                parameter RegulatoryDomain = "US";
                parameter AP_Mode = 1;
                parameter WDS_Mode = 1;
                parameter AirtimeFairnessEnabled = 1;
                parameter IntelligentAirtimeSchedulingEnable = 1;
                parameter MultiUserMIMOEnabled = 1;
                parameter RxPowerSaveEnabled = 1;
                parameter RetryLimit = 7;
                parameter BeaconPeriod=100;
                parameter DTIMPeriod=3;
                parameter TargetWakeTimeEnable = 1;
                parameter RxBeamformingCapsEnabled = "DEFAULT";
                parameter TxBeamformingCapsEnabled = "DEFAULT";
                parameter MCS = -1;
                parameter ProbeRequestNotify = "AlwaysRSSI";
                parameter ProbeRequestAggregationTimer = 1000;
                parameter OperatingStandards = "auto";
                parameter AutoBandwidthSelectMode="MaxAvailable";
                parameter OperatingChannelBandwidth="160MHz";
                parameter STA_Mode = 1;
                parameter STASupported_Mode = 1;
                object MACConfig {
                    parameter UseBaseMacOffset = true;
                    parameter BaseMacOffset = 3;
                    parameter UseLocalBitForGuest = true;
                    parameter LocalGuestMacOffset = 65536;
                }
            }
        }
        object SSID {
            instance add ("vap6g0priv") {
                parameter LowerLayers = "Device.WiFi.Radio.3.";
                parameter SSID = "prplOS";
                parameter Enable = 0;
            }
            instance add ("vap6g0guest") {
                parameter LowerLayers = "Device.WiFi.Radio.3.";
                parameter SSID = "prplOS-guest";
                parameter Enable = 0;
            }
        }
        object AccessPoint {
            instance add ("vap6g0priv") {
                parameter SSIDReference = "Device.WiFi.SSID.6.";
                parameter Enable = 0;
                parameter RetryLimit = 3;
                parameter WMMEnable = 1;
                parameter UAPSDEnable = 0;
                parameter MCEnable = 0;
                parameter DefaultDeviceType = "Data";
                parameter IEEE80211kEnabled = 0;
                parameter WDSEnable = 1;
                parameter MBOEnable = 0;
                parameter MultiAPType = "FronthaulBSS";
                parameter ApRole = "Off";
                parameter SSIDAdvertisementEnabled = 1;
                parameter BridgeInterface = "{{BD.Bridges.Lan.Name}}";
                object Security {
                    parameter ModesAvailable = "WPA3-Personal";
                    parameter WEPKey = "123456789ABCD";
                    parameter PreSharedKey = "";
                    parameter KeyPassPhrase = "password";
                    parameter RekeyingInterval = 0;
                    parameter OWETransitionInterface = "";
                    parameter SAEPassphrase = "password";
                    parameter EncryptionMode = "Default";
                    parameter SHA256Enable = 0;
                    parameter RadiusServerIPAddr = "";
                    parameter RadiusServerPort = 1812;
                    parameter RadiusSecret = "";
                    parameter RadiusDefaultSessionTimeout = 0;
                    parameter RadiusNASIdentifier = "";
                    parameter RadiusCalledStationId = "";
                    parameter RadiusChargeableUserId = 0;
                    parameter ModeEnabled = "WPA3-Personal";
                }
                object DriverConfig {
                    parameter BssMaxIdlePeriod = -1;
                }
            }
            instance add ("vap6g0guest") {
                parameter SSIDReference = "Device.WiFi.SSID.7.";
                parameter Enable = 0;
                parameter WMMEnable = 1;
                parameter DefaultDeviceType = "Guest";
                parameter IEEE80211kEnabled = 0;
                parameter WDSEnable = 0;
                parameter MBOEnable = 0;
                parameter MultiAPType = "BackhaulBSS";
                parameter ApRole = "Off";
                parameter SSIDAdvertisementEnabled = 1;
                parameter BridgeInterface = "{{BD.Bridges.Lan.Name}}";
                object Security {
                    parameter ModesAvailable = "WPA3-Personal";
                    parameter WEPKey = "123456789ABCD";
                    parameter PreSharedKey = "";
                    parameter KeyPassPhrase = "password";
                    parameter RekeyingInterval = 0;
                    parameter SAEPassphrase = "password";
                    parameter EncryptionMode = "Default";
                    parameter ModeEnabled = "WPA3-Personal";
                }
            }
        }
    }
}
