%populate {
    object WiFi {
        object Radio {
            object 'wifi1' {
                parameter STA_Mode = 1;
                parameter STASupported_Mode = 1;
            }
        }
    }
}
