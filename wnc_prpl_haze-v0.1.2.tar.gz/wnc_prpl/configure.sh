
DO_REVERT=0

TMP_PATCH_PATH_FILE=TMP_PATCH_PATH_FILE 
TMP_PATCH_FILE=TMP_PATCH_FILE
TMP_PATCH_FILE_REVERT=TMP_PATCH_FILE_REVERT
TMP_OVERLAY_FILES_FILE=TMP_OVERLAY_FILES_FILE
TMP_FEEDS_BRANCH=TMP_FEEDS_BRANCH
TMP_FEEDS_LEAF=TMP_FEEDS_LEAF

CUR_DIR=$( pwd )
SH_DIR=$( dirname $0 )
cd $SH_DIR/ > /dev/null
CONFIG_DIR=$(realpath --relative-to=".." ".") 
PROFILE_DIR=$CONFIG_DIR/profiles
cd ..
TOP_DIR=$( pwd )

do_feeds() {
	local action=$1
	local LINK_DIR="vendor_feed"
	local FEEDS_DIR="$CONFIG_DIR/$2/feeds"
			
	
	if [ $action != "apply" -a $action != "revert" ]; then
		echo "Wrong action to do patch"
		return
	fi
	
	if [ ! -e $FEEDS_DIR ]; then
		return
	fi

	find "$FEEDS_DIR" -maxdepth 1 -mindepth 1 -exec basename {} \; > "$TOP_DIR/$TMP_FEEDS_BRANCH"
	while read feed_branch
	do
		mkdir -p "$LINK_DIR/$feed_branch"
		find "$FEEDS_DIR/$feed_branch" -maxdepth 1 -mindepth 1  -exec basename {} \; > "$TOP_DIR/$TMP_FEEDS_LEAF"
		while read feed_leaf
		do
			if [ $action == "apply" ]; then
				cd $FEEDS_DIR/$feed_branch
				new_path=$(realpath --relative-to="$TOP_DIR/$LINK_DIR/$feed_branch" "$feed_leaf")
				cd "$TOP_DIR"
				ln -s "$new_path" "$LINK_DIR/$feed_branch/$feed_leaf"
			else
				rm "$LINK_DIR/$feed_branch/$feed_leaf" > /dev/null 2>&1
			fi
		done < "$TOP_DIR/$TMP_FEEDS_LEAF" 
	done < "$TOP_DIR/$TMP_FEEDS_BRANCH"

	rm "$TOP_DIR/$TMP_FEEDS_LEAF" -fr > /dev/null 2>&1  
	rm "$TOP_DIR/$TMP_FEEDS_BRANCH" -fr > /dev/null 2>&1  
	
	if [ $action == "revert" ]; then
		local link_num=`find "$LINK_DIR" -type l | wc -l`
		if [ $link_num == "0" ]; then
		    rm "$LINK_DIR" -fr > /dev/null 2>&1
		fi
	fi
}

do_deletion() {
	local action=$1
	local DELETION_DIR="$CONFIG_DIR/$2/deletion"
	local BACKUP_DIR="$TOP_DIR/deleted"

    if [ $action != "apply" -a $action != "revert" ]; then
		echo "Wrong action to do deletion"
		return
	fi

	if [ -e "$DELETION_DIR/index" ]; then
		if [ ! -e "BACKUP_DIR" ]; then
			mkdir "$BACKUP_DIR" > /dev/null 2>&1  	
		fi
	    while read DELETED
	    do
	    	if [ $action == "apply" ]; then  
	    		item_path=$( dirname "$DELETED" )
		    	if [ "$item_path" != "." ]; then
		    		mkdir -p "$BACKUP_DIR/$item_path" 
		    	fi
		    	rm "$BACKUP_DIR/$DELETED" -fr
		    	mv "$DELETED" "$BACKUP_DIR/$item_path" -f
		    elif [ $action == "revert" ]; then
		    	rm "$DELETED" -fr
		    	mv "$BACKUP_DIR/$DELETED" $DELETED
		    fi
	    done < "$DELETION_DIR/index"
	fi
    
	if [ $action == "revert" -a "$2" == "" ]; then
		rm "$BACKUP_DIR" -fr 			    
	fi
}

do_overlays() {
	local action=$1
	local OVERLAYS_DIR=$CONFIG_DIR/$2/overlays
 
	if [ $action != "apply" -a $action != "revert" ]; then
		echo "Wrong action to do patch"
		return
	fi

	if [ ! -e $OVERLAYS_DIR ]; then
		return
	fi

	if [ $action == "apply" ]; then
		cp "$OVERLAYS_DIR"/* "$TOP_DIR" -a
	else
		cd "$OVERLAYS_DIR"	
		find -type f > "$TOP_DIR/$TMP_OVERLAY_FILES_FILE"
		cd "$TOP_DIR"
		while read OVERLAY
		do
			rm "$OVERLAY" -f > /dev/null 2>&1
		done < "$TOP_DIR/$TMP_OVERLAY_FILES_FILE"
		rm "$TOP_DIR/$TMP_OVERLAY_FILES_FILE" > /dev/null 2>&1  
	fi
}

do_patches() { 
	local action=$1
	if [ $action != "apply" -a $action != "revert" -a $action != "collect" -a $action != "start" -a $action != "end" ]; then
		echo "Wrong action to do patch"
		return
	fi
	if [ $action == "collect" ]; then
		local PATCHES_DIR=$CONFIG_DIR/$2/patches-top-level

		if [ ! -e $PATCHES_DIR ]; then
			return
		fi

		find "$PATCHES_DIR" -name "*.patch" -exec dirname {} \; | uniq > "$TMP_PATCH_PATH_FILE"

		while read PATCH_PATH
		do
			find "$PATCH_PATH" -maxdepth 1 -name "*.patch" | sort >> "$TMP_PATCH_FILE" 
		done < "$TMP_PATCH_PATH_FILE"
		tac "$TMP_PATCH_FILE" > "$TMP_PATCH_FILE_REVERT"
		rm "$TMP_PATCH_PATH_FILE" -f > /dev/null 2>&1 
	elif [ $action == "apply" ]; then
		if [ -e "$TMP_PATCH_FILE" ]; then
			while read PATCH_FILE
			do
				git apply -v "$PATCH_FILE"
				if [ $? != 0 ]; then
					echo "#########################################################"
					echo "##############git apply fail, please fix!!###############"
					echo "#########################################################"
					rm "$TMP_PATCH_PATH_FILE" > /dev/null 2>&1  
					rm "$TMP_PATCH_FILE" > /dev/null 2>&1 
					rm "$TMP_PATCH_FILE_REVERT" > /dev/null 2>&1
					cd "$CUR_DIR"
					exit 1
				fi
			done < "$TMP_PATCH_FILE"
		fi			 
	elif [ $action == "revert" ]; then
		if [ -e "$TMP_PATCH_FILE_REVERT" ]; then
			while read PATCH_FILE
			do
				git apply -R "$PATCH_FILE" > /dev/null 2>&1
			done < "$TMP_PATCH_FILE_REVERT"
		fi
	elif [ $action == "start" -o $action == "end" ]; then
		rm "$TMP_PATCH_FILE" -f > /dev/null 2>&1 
		rm "$TMP_PATCH_FILE_REVERT" -f > /dev/null 2>&1
	fi
}


print_profiles() {
	local profiles=`find "$CONFIG_DIR/profiles" -type f -exec basename {} \;`
	echo "Avaialbe Profiles:"
	for profile in $profiles
	do
	    echo -n " "$profile
	done
	echo	  
}
 
print_help() {
	local profiles=`find "$CONFIG_DIR/profiles" -type f -exec basename {} \;`
	echo "Format: configure.sh profile"
	echo "Example: configure.sh chr2-bsp"
	print_profiles	  
}

if [ $# == 0 ]; then
    print_help
	exit 1
fi

do_patches start

while (( $# > 0 ))
do
	if [ "$1" == -R ]; then
		DO_REVERT=1
	else
		PROFILE="$PROFILE_DIR/$1"
	
		if [ -e "$PROFILE" ]; then
			while read line
			do
				if [ $DO_REVERT == 0 ]; then
					do_feeds revert $line
					do_feeds apply $line 
					do_deletion apply $line
					do_overlays apply $line
					do_patches collect $line
				else
					do_patches collect $line
					do_overlays revert $line
					do_deletion revert $line 
					do_feeds revert $line
				fi	
			done < $PROFILE
		else
			echo "Wrong Profile \"$1\""
			print_profiles
			cd "$CUR_DIR"
			exit 1
		fi
	fi
 
	shift 
done

if [ $DO_REVERT == 0 ]; then
	do_patches revert
	do_patches apply
else
	do_patches revert
	do_deletion revert
fi
do_patches end

cd "$CUR_DIR"
